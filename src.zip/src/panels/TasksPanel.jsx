export default function TasksPanel({ items, api }){
  return (
    <div className="card">
      <div className="row" style={{justifyContent:'space-between'}}>
        <h2>Задачи</h2>
        <button className="btn secondary" onClick={()=>window.location.reload()}>Обновить</button>
      </div>
      <ul className="list">
        {items.map(r => (
          <li className="item" key={r.id}>
            <div>
              <div>{r.text}</div>
              <div className="status">{new Date(r.due).toLocaleString()}</div>
            </div>
            <button className="btn danger" onClick={()=>api.remove(r.id)}>Удалить</button>
          </li>
        ))}
        {!items.length && <div className="status">Пока нет напоминаний.</div>}
      </ul>
    </div>
  )
}
