import { useEffect, useState } from 'react'
import { login, signup, logout, me } from '../api/auth.js'

export default function AuthPanel({ onAuthed }){
  const [email, setEmail] = useState('')
  const [pass, setPass] = useState('')
  const [status, setStatus] = useState('Проверка…')
  const [user, setUser] = useState(null)

  useEffect(() => {
    me().then(u => { setUser(u); setStatus('Вошли как '+u.email) }).catch(()=> setStatus('Не вошли'))
  }, [])

  return (
    <div className="card">
      <h2>Аккаунт</h2>
      <div className="status">{status}</div>
      {!user ? (
        <div className="grid two" style={{marginTop:12}}>
          <div>
            <h3>Регистрация</h3>
            <input className="input" type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
            <input className="input" type="password" placeholder="Пароль" value={pass} onChange={e=>setPass(e.target.value)} />
            <button className="btn" onClick={async ()=>{
              try{
                const u = await signup(email, pass)
                setUser(u); setStatus('Вошли как '+u.email); onAuthed?.(u)
              }catch(e){ setStatus('Ошибка регистрации') }
            }}>Создать аккаунт</button>
          </div>
          <div>
            <h3>Вход</h3>
            <input className="input" type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
            <input className="input" type="password" placeholder="Пароль" value={pass} onChange={e=>setPass(e.target.value)} />
            <button className="btn" onClick={async ()=>{
              try{
                const u = await login(email, pass)
                setUser(u); setStatus('Вошли как '+u.email); onAuthed?.(u)
              }catch(e){ setStatus('Ошибка входа') }
            }}>Войти</button>
          </div>
        </div>
      ) : (
        <div className="row" style={{marginTop:12}}>
          <button className="btn secondary" onClick={async ()=>{ await logout(); setUser(null); setStatus('Не вошли') }}>Выйти</button>
        </div>
      )}
    </div>
  )
}
