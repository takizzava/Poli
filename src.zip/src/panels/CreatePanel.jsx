import { useState } from 'react'

export default function CreatePanel({ api }){
  const [text, setText] = useState('')
  const [when, setWhen] = useState('')

  return (
    <div className="card">
      <h2>Создать вручную</h2>
      <div className="grid two">
        <input className="input" placeholder="Текст" value={text} onChange={e=>setText(e.target.value)} />
        <input className="input" type="datetime-local" value={when} onChange={e=>setWhen(e.target.value)} />
      </div>
      <div className="row" style={{marginTop:8}}>
        <button className="btn" onClick={async ()=>{
          if (!text || !when) return
          const due = new Date(when).getTime()
          await api.create(text, due)
          setText(''); setWhen('')
        }}>Добавить</button>
      </div>
    </div>
  )
}
