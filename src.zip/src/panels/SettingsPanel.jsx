import { useEffect, useState } from 'react'
import PushControls from '../components/PushControls.jsx'

const SKINS = ['classic','vinyl','neon','minimal']

export default function SettingsPanel(){
  const [skin, setSkin] = useState(localStorage.getItem('micSkin') || 'classic')

  useEffect(() => {
    const btn = document.getElementById('mic-btn')
    if (!btn) return
    SKINS.forEach(k => btn.classList.remove('skin-'+k))
    btn.classList.add('skin-'+skin)
    localStorage.setItem('micSkin', skin)
  }, [skin])

  return (
    <div className="card">
      <h2>Настройки</h2>
      <div className="grid two">
        <label>Скин кнопки микрофона
          <select value={skin} onChange={e=>setSkin(e.target.value)}>
            <option value="classic">Классика</option>
            <option value="vinyl">Винил</option>
            <option value="neon">Неон</option>
            <option value="minimal">Минимал</option>
          </select>
        </label>
        <div/>
      </div>
      <div style={{marginTop:16}}>
        <PushControls />
      </div>
    </div>
  )
}
