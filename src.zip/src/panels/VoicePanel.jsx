// src/panels/VoicePanel.jsx
import { useEffect, useState } from 'react'
import MicButton from '../components/MicButton.jsx'
import { useSpeech } from '../speech/useSpeech.js'
import { parse, formatDueSpoken } from '../utils/parser.js'
import { askAI } from '../api/ai.js'
import { createReminder } from '../api/reminders.js'

export default function VoicePanel({ status, setStatus, heard, setHeard }){
  const [listening, setListening] = useState(false)
  const [interim, setInterim] = useState('')
  const [woke, setWoke] = useState(false)

  const isReminder = (s='')=>{
    const t = s.toLowerCase()
    return t.includes('напомни')
        || t.includes('напоминан')   // напоминание/напомнить
        || t.includes('создай напомин')
        || t.includes('добавь напомин')
  }

  const speech = useSpeech({
    onInterim: (text) => setInterim(text || ''),
    onFinal:   async (text) => {
      setHeard?.(text || ''); setInterim('')
      if (!text) return

      if (isReminder(text)) {
        const p = parse(text, new Date())
        if (!p){
          setStatus?.('Не поняла дату/время. Скажи, например: «завтра в 12 купить хлеб».')
          return
        }
        setStatus?.(`Создаю напоминание ${formatDueSpoken(p.due)}: ${p.task}`)
        try {
          const saved = await createReminder(p.task, p.due.getTime())
          setStatus?.(`✅ Создала: ${p.task} — ${formatDueSpoken(p.due)}`)
        } catch (e) {
          const msg = e?.message || ''
          console.error('[createReminder]', msg)
          setStatus?.(msg.includes('401') ? 'Нужно войти в аккаунт' : 'Не удалось создать напоминание')
        }
        return
      }

      // иначе — вопрос к ИИ
      setStatus?.('Думаю над ответом…')
      try{
        const { reply } = await askAI(text)
        setStatus?.('Ответ: ' + (reply || 'Готово.'))
      }catch{
        setStatus?.('Ответ: Извините, ответ сейчас недоступен.')
      }
    },
    onStart: () => { setListening(true); setStatus?.('Скажи «Поли»') },
    onStop:  () => { setListening(false); setStatus?.('Микрофон выключен'); setInterim('') },
    onWake:  () => { setWoke(true); setTimeout(()=>setWoke(false), 650); setStatus?.('Говори команду…') }
  })

  useEffect(() => {
    setStatus?.('Привет! Я Поли. Нажми на микрофон и скажи: «Поли, напомни завтра в двенадцать купить хлеб».')
  }, [])

  return (
    <div className="card voice-mode">
      <div className="voice-status">
        <div className="status-text">{status || (listening ? 'Скажи «Поли»' : '')}</div>
      </div>

      {/* Живой текст аккуратно */}
      <div className="chat">
        {interim && (
          <div className="msg user typing">
            <div className="bubble">{interim}</div>
          </div>
        )}
        {heard && (
          <div className="msg user">
            <div className="bubble">{heard}</div>
          </div>
        )}
      </div>

      <MicButton
        listening={listening}
        woke={woke}
        onClick={() => (listening
          ? speech.stop()
          : (window.__poliPrimeAudio && window.__poliPrimeAudio(), speech.start())
        )}
        onHold={async () => { if (!listening) speech.start(); speech.forceCapture(); }}
      />

      {!speech.supported && (
        <div className="status">Ваш браузер не поддерживает Web Speech API.</div>
      )}
    </div>
  )
}
