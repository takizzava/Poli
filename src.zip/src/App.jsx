import { useEffect, useMemo, useState } from 'react'
import VoicePanel from './panels/VoicePanel.jsx'
import CreatePanel from './panels/CreatePanel.jsx'
import TasksPanel from './panels/TasksPanel.jsx'
import SettingsPanel from './panels/SettingsPanel.jsx'
import AuthPanel from './panels/AuthPanel.jsx'
import ThemeToggle from './components/ThemeToggle.jsx'
import { listReminders, createReminder, deleteReminder } from './api/reminders.js'
import { me } from './api/auth.js'

const TABS = ['voice','create','tasks','settings','auth']

export default function App(){
  const [tab, setTab] = useState('voice')
  const [status, setStatus] = useState('Готова. Скажи «Поли».')
  const [heard, setHeard] = useState('')
  const [items, setItems] = useState([])
  const [user, setUser] = useState(null)

  useEffect(() => {
    const saved = localStorage.getItem('theme') || 'dark'
    document.documentElement.classList.toggle('light', saved === 'light')
    me().then(setUser).catch(()=>{})
    refresh().catch(()=>{})
    if ('serviceWorker' in navigator){
      navigator.serviceWorker.addEventListener('message', (e)=>{
        if (e?.data?.type === 'edi-push'){
          const d = e.data.data || {}
          setStatus('🔔 '+(d.title||'Пуш')+': '+(d.body||''))
        }
      })
    }
  }, [])

  async function refresh(){ setItems(await listReminders()) }

  const api = useMemo(() => ({
    create: async (text, due) => { await createReminder(text, due); await refresh() },
    remove: async (id) => { await deleteReminder(id); await refresh() }
  }), [])

  return (
    <div className="app">
      <header className="header">
        <div className="brand">
          <div className="logo"/>
          <div>
            <div className="title">Поли</div>
            <div className="subtitle">Голосовые напоминания + ответы</div>
          </div>
        </div>
        <div className="nav">
          {TABS.map(t => (
            <button key={t} className={'tab'+(tab===t?' active':'')} onClick={()=>setTab(t)}>
              {t==='voice'?'🎤 Голос': t==='create'?'➕ Создать': t==='tasks'?'🗂 Задачи': t==='settings'?'⚙️ Настройки':'🔐 Аккаунт'}
            </button>
          ))}
          <ThemeToggle />
        </div>
      </header>

      <main className="main">
        {tab==='voice' && <VoicePanel status={status} setStatus={setStatus} heard={heard} setHeard={setHeard} />}
        {tab==='create' && <CreatePanel api={api} />}
        {tab==='tasks' && <TasksPanel items={items} api={api} />}
        {tab==='settings' && <SettingsPanel />}
        {tab==='auth' && <AuthPanel onAuthed={(u)=>{ setUser(u); setTab('voice') }} />}
      </main>

      <footer className="footer">
        <div className="small muted">© {new Date().getFullYear()} Поли</div>
      </footer>
    </div>
  )
}
