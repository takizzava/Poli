// src/utils/parser.js
import dayjs from 'dayjs'
import 'dayjs/locale/ru.js'
dayjs.locale('ru')

const MONTHS = {
  'янв':'01','фев':'02','мар':'03','апр':'04','май':'05','мая':'05','июн':'06','июл':'07','авг':'08','сен':'09','сент':'09','окт':'10','ноя':'11','дек':'12'
}
const WEEK = ['воскресенье','понедельник','вторник','среда','четверг','пятница','суббота']

// Юникод-«границы слова»: вместо \b используем «не буква/цифра/подчёркивание»
const WB = String.raw`(?:^|[^\p{L}\p{N}_])`
const WE = String.raw`(?=$|[^\p{L}\p{N}_])`
const re = (s, flags='iu') => new RegExp(s, flags)

export function formatDueSpoken(d){
  const date = dayjs(d)
  const today = dayjs().startOf('day')
  const tomorrow = today.add(1,'day')
  const dayAfter = today.add(2,'day')
  if (date.isSame(today,'day')) return 'сегодня в '+date.format('HH:mm')
  if (date.isSame(tomorrow,'day')) return 'завтра в '+date.format('HH:mm')
  if (date.isSame(dayAfter,'day')) return 'послезавтра в '+date.format('HH:mm')
  return date.format('D MMMM в HH:mm')
}

export function parse(input, now = new Date()){
  let text = (input||'').toLowerCase().replace(/\s+/g,' ').trim()
  const base = dayjs(now)

  // выкинем «… напомни …» в начале — без \b, с юникод-границами
  const rmRemind = re(`^.*?${WB}напомни${WE}[,:]?\\s*`)
  text = text.replace(rmRemind,'').trim()

  // 1) относительные: «через N минут/часов», «через полчаса»
  const rel = text.match(/через\s+((\d+)\s*(минут[уы]?|мин|m|м))?\s*((\d+)\s*(час[ауов]?|ч|h))?/i)
  if (rel){
    const m = rel[2] ? parseInt(rel[2],10) : 0
    const h = rel[5] ? parseInt(rel[5],10) : 0
    let minutes = ( /полчаса/.test(text) ? 30 : 0 ) + m + h*60
    if (minutes > 0){
      const due = base.add(minutes,'minute').toDate()
      const task = text
        .replace(/через.*?(минут[уы]?|мин|m|м|час[ауов]?|ч|h).*/,'')
        .replace(/через\s+полчаса/,'')
        .trim()
      return { task: cleanupTask(task, text), due }
    }
  }

  // 2) явная дата dd.mm или dd month
  const ddmm = text.match(/\b(\d{1,2})[\.\/-](\d{1,2})(?:[\.\/-](\d{2,4}))?\b/)
  if (ddmm){
    const d = parseInt(ddmm[1],10)
    const m = parseInt(ddmm[2],10)-1
    const y = ddmm[3] ? parseInt(ddmm[3],10) : base.year()
    const date = dayjs(new Date(y, m, d)).hour(9).minute(0).second(0)
    const task = text.replace(ddmm[0],'').trim()
    return { task: cleanupTask(task, text), due: date.toDate() }
  }
  const dmon = text.match(re(String.raw`\b(\d{1,2})\s+(янв\w*|фев\w*|мар\w*|апр\w*|ма[йя]|июн\w*|июл\w*|авг\w*|сен\w*|окт\w*|ноя\w*|дек\w*)\b`))
  if (dmon){
    const d = parseInt(dmon[1],10)
    const mon = (dmon[2]||'').slice(0,3)
    const m = parseInt(MONTHS[mon],10)-1
    const date = dayjs(new Date(base.year(), m, d)).hour(9).minute(0)
    const task = text.replace(dmon[0],'').trim()
    return { task: cleanupTask(task, text), due: date.toDate() }
  }

  // 3) «сегодня/завтра/послезавтра» + время (или без -> 09:00)
  const dayWord = text.match(re(`${WB}(сегодня|завтра|послезавтра)${WE}`))
  if (dayWord){
    let d = base.startOf('day')
    const word = dayWord[1]
    if (word === 'завтра') d = d.add(1,'day')
    if (word === 'послезавтра') d = d.add(2,'day')
    const t = pickTime(text) || { h:9, m:0 }
    const dt = d.hour(t.h).minute(t.m)
    const task = text
      .replace(dayWord[0],' ')
      .replace(timeRegex(),' ')
      .replace(/\s+/g,' ')
      .trim()
    return { task: cleanupTask(task, text), due: dt.toDate() }
  }

  // 4) день недели + время
  const wd = text.match(re(`${WB}(в|во)\\s+(понедельник|вторник|среду|среда|четверг|пятницу|пятница|субботу|суббота|воскресенье)${WE}`))
  if (wd){
    const target = normWeekday(wd[2])
    const cur = base.day()
    let add = (target - cur + 7) % 7
    if (add === 0) add = 7
    const d = base.add(add,'day').startOf('day')
    const t = pickTime(text) || { h:9, m:0 }
    const dt = d.hour(t.h).minute(t.m)
    const task = text
      .replace(wd[0],' ')
      .replace(timeRegex(),' ')
      .replace(/\s+/g,' ')
      .trim()
    return { task: cleanupTask(task, text), due: dt.toDate() }
  }

  // 5) только время «в 7 вечера», «в 7 05 утра», «в 19:30»
  const t = pickTime(text)
  if (t){
    let dt = base.hour(t.h).minute(t.m)
    if (dt.isBefore(base)) dt = dt.add(1,'day') // если время уже прошло — завтра
    const task = text.replace(timeRegex(),' ').replace(/\s+/g,' ').trim()
    return { task: cleanupTask(task, text), due: dt.toDate() }
  }

  return null
}

function cleanupTask(task, original){
  task = task.replace(re(String.raw`^(мне|мне\s+пожалуйста)\s+`),'')
  task = task.replace(re(String.raw`^в\s+`),'').trim()
  if (!task) {
    const rest = original.replace(re(String.raw`^.*?${WB}напомни${WE}`),'').trim()
    const words = rest.split(/\s+/).slice(-4).join(' ')
    return words || 'напоминание'
  }
  return task
}

function pickTime(text){
  // в 7:05 / 19:30 / 7.05 + возможно «утра/вечера/ночи»
  let m = text.match(re(String.raw`${WB}в\s*(\d{1,2})[:.\s](\d{2})(\s*(утра|вечера|ночи))?${WE}`))
  if (m){
    let h = parseInt(m[1],10), mm = parseInt(m[2],10)
    const mode = m[4] || ''
    if (/вечера|ночи/.test(mode) && h<12) h += 12
    if (/утра/.test(mode) && h===12) h = 0
    return { h, m:mm }
  }
  // в 7 05 (без двоеточия)
  m = text.match(re(String.raw`${WB}в\s*(\d{1,2})\s*(\d{2})(\s*(утра|вечера|ночи))?${WE}`))
  if (m){
    let h = parseInt(m[1],10), mm = parseInt(m[2],10)
    const mode = m[4] || ''
    if (/вечера|ночи/.test(mode) && h<12) h += 12
    if (/утра/.test(mode) && h===12) h = 0
    return { h, m:mm }
  }
  // в 7 (утра/вечера/ночи)
  m = text.match(re(String.raw`${WB}в\s*(\d{1,2})(\s*(утра|вечера|ночи))?${WE}`))
  if (m){
    let h = parseInt(m[1],10)
    const mode = m[3] || ''
    if (/вечера|ночи/.test(mode) && h<12) h += 12
    if (/утра/.test(mode) && h===12) h = 0
    return { h, m:0 }
  }
  return null
}

function timeRegex(){
  // Используем юникод-границы, флаг g — чтобы вырезать время из задачи
  return re(String.raw`${WB}в\s*\d{1,2}(?:[:.\s]\d{2})?(?:\s*(?:утра|вечера|ночи))?${WE}`, 'igu')
}

function normWeekday(w){
  w = w.replace('среду','среда').replace('пятницу','пятница').replace('субботу','суббота')
  return ['воскресенье','понедельник','вторник','среда','четверг','пятница','суббота'].indexOf(w)
}
