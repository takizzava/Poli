import './skin-switcher.css'

const SKINS = ['aqua','coral','violet','lime']

export default function SkinSwitcher({ skin, onChange }){
  return (
    <div className="skin-switcher">
      {SKINS.map(s => (
        <button
          key={s}
          type="button"
          data-skin={s}
          className={s===skin ? 'active' : ''}
          aria-label={`Скин ${s}`}
          onClick={()=> onChange?.(s)}
        />
      ))}
    </div>
  )
}
