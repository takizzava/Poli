import { useRef, useState } from 'react'
import '../styles/mic-button.css'
import '../styles/mic-skins.css' // палитры из твоей панели

/**
 * Совместимо с SettingsPanel:
 *  - Имеет id="mic-btn"
 *  - Поддерживает классы skin-classic|skin-vinyl|skin-neon|skin-minimal
 */
export default function MicButton({
  listening,
  woke = false,
  onClick,
  onHold,
  className = ''
}) {
  const holdTimer = useRef(null)
  const [holding, setHolding] = useState(false)

  // скин по умолчанию — тот, что лежит у тебя в localStorage
  const defaultSkin =
    (typeof window !== 'undefined' && localStorage.getItem('micSkin')) || 'classic'

  const startHold = () => {
    if (!onHold) return
    clearTimeout(holdTimer.current)
    holdTimer.current = setTimeout(() => {
      setHolding(true)
      onHold()
    }, 400)
  }
  const endHold = () => {
    clearTimeout(holdTimer.current)
    setHolding(false)
  }

  const cls = [
    'mic',
    `skin-${defaultSkin}`,      // чтобы сразу был выбранный скин
    listening ? 'is-on' : 'is-off',
    woke ? 'wake' : '',
    holding ? 'holding' : '',
    className
  ].join(' ')

  return (
    <button
      id="mic-btn"
      type="button"
      className={cls}
      onMouseDown={startHold}
      onMouseUp={endHold}
      onMouseLeave={endHold}
      onTouchStart={startHold}
      onTouchEnd={endHold}
      onClick={(e) => {
        endHold()
        onClick?.(e)
      }}
      aria-pressed={listening}
      aria-label={listening ? 'Поли слушает' : 'Включить микрофон'}
    >
      <span className="ring ring-1" />
      <span className="ring ring-2" />
      <span className="core" />
      <span className="label">{listening ? 'Поли слушает…' : 'Скажи «Поли»'}</span>
    </button>
  )
}