export default function ThemeToggle(){
  return (
    <button className="tab" onClick={()=>{
      const isLight = document.documentElement.classList.contains('light')
      document.documentElement.classList.toggle('light', !isLight)
      localStorage.setItem('theme', !isLight ? 'light' : 'dark')
      const meta = document.querySelector('meta[name=theme-color]')
      if (meta) meta.setAttribute('content', !isLight ? '#f8fafc' : '#0b1020')
    }}>🌓</button>
  )
}
