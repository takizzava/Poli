// client/api/ai.js — calls our server-side YandexGPT proxy
export async function askAI(text) {
  const r = await fetch('/api/ai', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text }),
    credentials: 'include'
  })
  if (!r.ok) throw new Error('ai failed')
  return await r.json()
}
